let cantCuotas,monto;

monto = parseInt(prompt("ingrese un monto"));
cantCuotas = parseInt(prompt("Ingrese cantidad de cuotas"));


function calcularCuotas(monto, cantidadDeCuotas){
	let resultado,porcentaje;
	switch(cantidadDeCuotas){
		case 1:
			porcentaje=1;
			break;
		case 3:
			porcentaje=0.15;
			break;
		case 6:
			porcentaje=0.50;
			break;
		case 9:
			porcentaje=0.75;
			break;
		case 12:
			porcentaje=2;
			break;
		default:
			alert("valor no valido")
	}
	resultado=monto*porcentaje;
	return resultado;
}

document.write("<h2>Costo total a pagar: "+calcularCuotas(monto,cantCuotas)+"</h2>");